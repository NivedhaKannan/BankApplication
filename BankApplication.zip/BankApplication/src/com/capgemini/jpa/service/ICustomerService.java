package com.capgemini.jpa.service;

import com.capgemini.jpa.entity.Customer;
import com.capgemini.jpa.exception.CustomerException;

public interface ICustomerService {
	public void createAccount(Customer customer)throws CustomerException;
	public boolean validateName(String cname)throws CustomerException;
	public boolean validateAddress(String caddress)throws CustomerException;
	public boolean validatePhnno(String cphnno)throws CustomerException;
	public boolean validateAadharno(String caadharno)throws CustomerException;
	public boolean validateAge(int age)throws CustomerException;
	public boolean validateBal(double balance)throws CustomerException;
	public double withDraw(int accNum,double amt)throws CustomerException;
	public double deposit(int accNum,double amt)throws CustomerException;
	public double showBalance(int accNum)throws CustomerException;
	public boolean fundTransfer(int accNum,int funacc,double amt)throws CustomerException;
	public void printTransaction(int accNum)throws CustomerException;
	public boolean validateBalance(int accNum,double amt)throws CustomerException;
	
}
