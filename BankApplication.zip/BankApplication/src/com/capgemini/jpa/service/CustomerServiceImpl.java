package com.capgemini.jpa.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.jpa.DAO.CustomerDAOImpl;
import com.capgemini.jpa.DAO.ICustomerDao;
import com.capgemini.jpa.entity.Customer;
import com.capgemini.jpa.exception.CustomerException;



public class CustomerServiceImpl implements ICustomerService{
	ICustomerDao CustomerDAO=new CustomerDAOImpl();
	
	public void createAccount(Customer customer)throws CustomerException
	{
		CustomerDAO.createAccount(customer);
	}
	
	public double showBalance(int accNum)throws CustomerException
	{
		return CustomerDAO.showBalance(accNum);
	}
	public boolean fundTransfer(int accNum,int funacc,double amt)throws CustomerException
	{
		return CustomerDAO.fundTransfer(accNum,funacc,amt);
	}
	public String printTransaction(int accNum)throws CustomerException
	{
		return CustomerDAO.printTransaction(accNum);
	}
	public double withDraw(int accNum ,double amt)throws CustomerException 
	{
		return CustomerDAO.withDraw(accNum,amt);
	}
	
	public double deposit(int accNum,double amt)throws CustomerException 
	{
		return CustomerDAO.deposit(accNum,amt);
	}
	public boolean validateBalance(int accNum,double amt)throws CustomerException
	{
		return CustomerDAO.validateBalance(accNum, amt);
	}
	public boolean validateName(String cname)throws CustomerException
	{
		boolean flag=false;
		Pattern Name=Pattern.compile("[A-Z][a-z\\sA-Z]+");
		Matcher Namematch=Name.matcher(cname);
		if(Namematch.matches()&&cname.length()>2) 
		{
			flag=true;
		}
		else
		{
			System.err.println("\n Enter the NAME correctly");
		}
			return flag;
	}
	public boolean validateAge(int age)throws CustomerException
	{
		boolean flag=false;
		if(age>10&&age<80)
		{
			return true;
		}
		else
		{
			System.err.println("\n Invalid age");
		}
		return flag;
	}
	
	public boolean validatePhnno(String cphnno)throws CustomerException
	{
		boolean flag=false;
		Pattern Mob=Pattern.compile("[6-9][0-9]{9}");
		Matcher Mobmatch=Mob.matcher(cphnno);
		if(Mobmatch.matches()) 
		{
			flag=true;
			}
		else
		{
			System.err.println("\n Enter the MOBILE NUMBER correctly");
		}
			return flag;
		}
	public boolean validateAddress(String caddress)throws CustomerException
	{
		boolean flag=false;
		Pattern Addr=Pattern.compile("^[0-9][A-Za-z0-9\\s,.#-]*");
		Matcher Addrmatch=Addr.matcher(caddress);
		if(Addrmatch.matches()&&caddress.length()>3) 
		{
			flag=true;
			}
		else
		{
			System.err.println("\n Enter the ADDRESS correctly");
		}
			return flag;
		}
	public boolean validateAadharno(String caadharno)throws CustomerException
	{
		boolean flag=false;
		Pattern aadhar=Pattern.compile("[0-9]{12}");
		Matcher aadharmatch=aadhar.matcher(caadharno);
		if(aadharmatch.matches())
		{
			flag=true;
		}
		else
		{
			System.err.println("\n Enter the AADHAR NUMBER correctly");
		}
			return flag;
	}

	public boolean validateBal(double balance)throws CustomerException {
		{
			boolean flag=false;
			if(balance>100)
			{
				flag=true;
			}
			else
			{
				System.err.println("\n Enter a amount greater than 100");
			}
		
		return flag;
	}}}


	
	
	
	


