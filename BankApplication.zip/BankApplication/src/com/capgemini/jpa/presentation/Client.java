package com.capgemini.jpa.presentation;

import java.util.Random;
import java.util.Scanner;

import com.capgemini.jpa.entity.Customer;
import com.capgemini.jpa.exception.CustomerException;
import com.capgemini.jpa.service.CustomerServiceImpl;
import com.capgemini.jpa.service.ICustomerService;

public class Client {

	public static void main(String[] args)
	{

		ICustomerService customerService=new CustomerServiceImpl();

		Random random=new Random(); 


		while(true)
		{		System.out.println("\nWelcome to banking system");
		System.out.println("1.Create an account");
		System.out.println("2.Show balance");
		System.out.println("3.Withdraw amount");
		System.out.println("4.Deposit amount");
		System.out.println("5.Fund transfer");
		System.out.println("6.Print transactions");
		System.out.println("7.Exit");


		Scanner sc = new Scanner(System.in);
		Scanner sc1 = new Scanner(System.in);
		Scanner sc2 = new Scanner(System.in);
		Integer option = sc.nextInt();
		String cname,caddress,cphnno,caadharno;
		Integer cage;
		Double bal,balance;
		Integer funacc,accNum;
		Double amt;
		switch (option) 
		{
		case 1:

			try
			{
				Customer customer = new Customer();
				boolean flag;
				do {
					System.out.println("\nEnter your name[with Intial letter as Capital]");
					cname = sc1.nextLine();
					flag=customerService.validateName(cname);
				}while(flag==false);
				do {
					System.out.println("\nEnter your age");
					cage = sc.nextInt();
					flag=customerService.validateAge(cage);
				}while(flag==false);
				do {
					System.out.println("\nEnter your address");
					caddress= sc2.nextLine();
					flag=customerService.validateAddress(caddress);
				}while(flag==false);
				do
				{
					System.out.println("\nEnter your mobile number");
					cphnno=sc.next();
					flag=customerService.validatePhnno(cphnno);
				}while(flag==false);
				do
				{
					System.out.println("\nEnter your Aadharno");
					caadharno=sc.next();
					flag=customerService.validateAadharno(caadharno);
				}while(flag==false);
				do
				{
					System.out.println("\nEnter the opening balance");
					balance=sc.nextDouble();
					flag=customerService.validateBal(balance);
				}while(flag==false);

				customer.setCname(cname);
				customer.setCaddress(caddress);
				customer.setCphnno(cphnno);
				customer.setCaadharno(caadharno);
				customer.setBalance(balance);
				customer.setCage(cage);
				accNum=random.nextInt(10000); 
				customer.setAccNum(accNum);
				customerService.createAccount(customer);


				System.out.println("\n Your account number is \t"+customer.getAccNum());
				break;
			}catch(CustomerException e)
			{
				System.out.println("\n The exception is"+ e.getMessage());
			}

		case 2:
			System.out.println("Enter the account number");
			try {
				accNum=sc.nextInt();
				bal=customerService.showBalance(accNum);
				System.out.println("\n The balance in the account \t"+accNum+" is \t"+bal);
				break;
			}catch(CustomerException e)
			{
				System.out.println("\n The exception is"+ e.getMessage());
			}


		case 3:
			System.out.println("Enter the account number:");
			try {
				accNum=sc.nextInt();
				System.out.println(" Enter the amount to be withdrawn:");
				amt=sc.nextDouble();
				boolean d;
				d=customerService.validateBalance(accNum, amt);
				if(d)
				{
					bal=customerService.withDraw(accNum,amt);
					System.out.println("\n Amount has been withdrawn and the balance is\t"+bal);
				}else
				{
					System.err.println("Insufficient balance");
				}
				break;
			}catch(CustomerException e)
			{
				System.out.println("\n The exception is"+ e.getMessage());
			}


		case 4:
			try{
				System.out.println("Enter the account number:");
				accNum=sc.nextInt();
				System.out.println(" Enter the amount to be deposited:");
				amt=sc.nextDouble();
				bal=customerService.deposit(accNum,amt);
				System.out.println("\n amount has been deposited and the balance is\t"+bal);
				break;
			}catch(CustomerException e)
			{
				System.out.println("\n The exception is"+ e.getMessage());
			}


		case 5:
			try{
				System.out.println("Enter the account number:");
				accNum=sc.nextInt();
				System.out.println("Enter the account number to be transferred");
				funacc=sc.nextInt();
				System.out.println("\n Enter the amount to be transferred");
				amt=sc.nextDouble();
				if(customerService.fundTransfer(accNum, funacc,amt)==true)
				{
					System.out.println("\n Fundtransfer is successful");
				}else
				{
					System.out.println("\n Transfer failed");
				}
				break;
			}
				catch(CustomerException e)
				{
					System.out.println("\n The exception is"+ e.getMessage());
				}

			case 6:
				try
				{
					System.out.println("Enter the account number");
					accNum=sc.nextInt();
					customerService.printTransaction(accNum);
					break;
				}catch(CustomerException e)
				{
					System.out.println("\n The exception is"+ e.getMessage());
				}

			case 7:
				System.exit(0);
				break;

			default:
				System.out.println("Wrong choice");
				break;
			}

		}                                       
		}

	}
