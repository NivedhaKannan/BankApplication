package com.capgemini.jpa.exception;

public class CustomerException extends Exception {
	private String status;
	
	public CustomerException() {
		this.status="Unable to perform operation";
	}
	
	public CustomerException(String status) {
		super(status);
	}

	public String getStatus() {
		return status;
	}

	@Override
	public String toString() {
		return "CustomerException [status=" + status + "]";
	}
	
}
