
package com.capgemini.jpa.DAO;

import com.capgemini.jpa.entity.Customer;
import com.capgemini.jpa.exception.CustomerException;



public interface ICustomerDao 
{
	public void createAccount(Customer customer)throws CustomerException;
	public double withDraw(int accNum,double amt)throws CustomerException;
	public double deposit(int accNum,double amt)throws CustomerException;
	public double showBalance(int accNum)throws CustomerException;
	public boolean fundTransfer(int accNum,int funacc,double amt)throws CustomerException;
	public String printTransaction(int accNum)throws CustomerException;

	public boolean validateBalance(int accNum,double amt)throws CustomerException;

}
