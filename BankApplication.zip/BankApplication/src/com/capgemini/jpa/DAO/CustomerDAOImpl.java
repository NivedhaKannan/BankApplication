package com.capgemini.jpa.DAO;


import javax.persistence.EntityManager;
import javax.persistence.Persistence;
import javax.persistence.PersistenceException;

import com.capgemini.jpa.entity.Customer;
import com.capgemini.jpa.exception.CustomerException;
import com.capgemini.jpa.utility.JPAUtil;



public class CustomerDAOImpl implements ICustomerDao
{
	private EntityManager entityManager=null;

	@Override
	public void createAccount(Customer customer)throws CustomerException
	{
		try
		{
			entityManager=JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
			entityManager.persist(customer);
			entityManager.getTransaction().commit();	
		}catch(PersistenceException e) {
			e.printStackTrace();
			throw new CustomerException(e.getMessage());
		}finally
		{
			entityManager.close();
		}
	}

	@Override
	public double showBalance(int accNum)throws CustomerException
	{
		try{
			entityManager=JPAUtil.getEntityManager();
			Customer cust=entityManager.find(Customer.class,accNum);
			return cust.getBalance();
		}catch(PersistenceException e) {
			e.printStackTrace();
			throw new CustomerException(e.getMessage());
		}finally
		{
			entityManager.close();
		}
	}
	@Override
	public double withDraw(int accNum,double amt)throws CustomerException
	{	
	
		try{
			entityManager=JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
			Customer cust=entityManager.find(Customer.class,accNum);
			double d=cust.getBalance() - amt;
			cust.setBalance(d);
			
			entityManager.merge(cust);
			entityManager.getTransaction().commit();
			return cust.getBalance();
		
		}catch(PersistenceException e) 
		{
			e.printStackTrace();
			throw new CustomerException(e.getMessage());
		}finally
		{
			entityManager.close();
		}
	}
	@Override
	public double deposit(int accNum,double amt) throws CustomerException
	{
	
		try{
			entityManager=JPAUtil.getEntityManager();
			Customer cust=entityManager.find(Customer.class,accNum);
	        cust.setBalance(cust.getBalance() + amt);
			entityManager.getTransaction().begin();
			entityManager.merge(cust);
			entityManager.getTransaction().commit();
			return cust.getBalance();
		}
		catch(PersistenceException e) {
			e.printStackTrace();
			throw new CustomerException(e.getMessage());
		}finally
		{
			entityManager.close();
		}
	}
@Override
	public boolean fundTransfer(int accNum,int funacc,double amt) throws CustomerException
	{
		
	try
	{
	entityManager=JPAUtil.getEntityManager();
	double newBal;
	entityManager.getTransaction().begin();
	Customer cus1 = entityManager.find(Customer.class, accNum);
	double tempBal = cus1.getBalance();
	if(tempBal>=amt)
	{
	newBal = cus1.getBalance()-amt;
	cus1.setBalance(newBal);
	Customer cus2 = entityManager.find(Customer.class,funacc);
	newBal = cus2.getBalance()+amt; 
	entityManager.merge(cus1);
	entityManager.merge(cus2);
	entityManager.getTransaction().commit();
	return true;
	}
	}catch(PersistenceException e)
	{
		e.printStackTrace();
		throw new CustomerException(e.getMessage());
	}finally
	{
		entityManager.close();
	}
	return false; 
/*try{
			withDraw(accNum,amt);
			int status=(int)deposit(funacc,amt);
			if(status>0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}catch(PersistenceException e) {
			e.printStackTrace();
			throw new CustomerException(e.getMessage());
		}
*/	}
	
	public boolean validateBalance(int accNum,double amt)throws CustomerException
	{
	  
			try{
			entityManager=JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
			Customer cust=entityManager.find(Customer.class,accNum);
			cust.getBalance();
			if(cust.getBalance()>=amt)
			{
				return true;
			}else
			{
			return false;
			}
		}catch(PersistenceException e) 
		{
			e.printStackTrace();
			throw new CustomerException(e.getMessage());
		}finally
		{
			entityManager.close();
		}
	}
		

	@Override
	public void printTransaction(int accNum) throws CustomerException {
		// TODO Auto-generated method stub
		
	}
}

