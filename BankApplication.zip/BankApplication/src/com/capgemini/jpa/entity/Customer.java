package com.capgemini.jpa.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

@Entity
public class Customer {
	@Id
	private Integer accNum;
	@NotNull
	private String cname;
	private String caddress;
	private String cphnno;
	private String caadharno;
	private String status;
	private Integer cage;
	private Double balance;

	public Customer()
	{

	}
	

	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public Customer(Integer accNum, String cname, String caddress,
			String cphnno, String caadharno, String status, Integer cage,
			Double balance) {
		super();
		this.accNum = accNum;
		this.cname = cname;
		this.caddress = caddress;
		this.cphnno = cphnno;
		this.caadharno = caadharno;
		this.status = status;
		this.cage = cage;
		this.balance = balance;
	}


	public Integer getAccNum() {
		return accNum;
	}


	public void setAccNum(Integer accNum) {
		this.accNum = accNum;
	}


	public String getCname() {
		return cname;
	}



	public void setCname(String cname) {
		this.cname = cname;
	}



	public Integer getCage() {
		return cage;
	}



	public void setCage(Integer cage) {
		this.cage = cage;
	}



	public Double getBalance() {
		return balance;
	}



	public void setBalance(Double balance) {
		this.balance = balance;
	}



	public String getCaddress() {
		return caddress;
	}



	public String getCaadharno() {
		return caadharno;
	}


	public void setCaddress(String caddress) {
		this.caddress = caddress;
	}
	public String getCphnno()	
	{
		return cphnno;
	}
	public void setCphnno(String cphnno){
		this.cphnno=cphnno;
	}
	public String getcaadharno()	
	{
		return caadharno;
	}
	public void setCaadharno(String caadharno){
		this.caadharno=caadharno;
	}


	@Override
	public String toString() {
		return "Customer [Your Account number is=" + accNum + ", Name=" + cname
				+ ", Address=" + caddress + ", Contact number=" + cphnno
				+ ", Aadharnumber=" + caadharno + ", Age=" + cage + ", Balance="
				+ balance + "]";
	}




}

